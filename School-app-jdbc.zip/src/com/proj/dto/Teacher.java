package com.proj.dto;

public class Teacher {
private int id;
private String name;
private String sub;
private String gender;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public String getSub() {
	return sub;
}
public void setSub(String sub) {
	this.sub = sub;
}
public String getGender() {
	return gender;
}
public void setGender(String gender) {
	this.gender = gender;
}
@Override
public String toString() {
	return "Teacher [id=" + id + ", name=" + name + ", sub=" + sub + ", gender=" + gender + ", getId()=" + getId()
			+ ", getName()=" + getName() + ", getSub()=" + getSub() + ", getGender()=" + getGender() + ", getClass()="
			+ getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString() + "]";
}

}

