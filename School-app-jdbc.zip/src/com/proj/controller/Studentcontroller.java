package com.proj.controller;

import java.util.ArrayList;

import com.proj.dao.StudentDao;
import com.proj.dto.Student;

public class Studentcontroller {
	public static void main(String[] args) {
		Student student3=new Student();
		student3.setId(6);
		student3.setName("hai");
		student3.setAge(21);
		student3.setGender("male");
		student3.setEmail("ky4@gmail.com");
		
		
		Student student4=new Student();
		student4.setId(7);
		student4.setName("aai");
		student4.setAge(22);
		student4.setGender("male");
		student4.setEmail("aai@gmail.com");
		
		
		Student student5=new Student();
		student5.setId(8);
		student5.setName("baha");
		student5.setAge(24);
		student5.setGender("male");
		student5.setEmail("baha@gmail.com");
		
		ArrayList<Student> students =new ArrayList<Student>();
		students.add(student3);
		students.add(student4);
		students.add(student5);
		
		
		StudentDao dao =new StudentDao();
		dao.saveAllStudent(students);
		
		
		//String s = dao.saveStudent(student);
		//System.out.println();
		//dao.deletestudentById(2);
		//dao.savedataStudent(1);
	}

}
