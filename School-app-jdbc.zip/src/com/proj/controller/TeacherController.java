package com.proj.controller;

import java.util.ArrayList;
import java.util.Scanner;

import com.proj.dao.TeacherDao;
import com.proj.dto.Teacher;

public class TeacherController {

	static Scanner scanner = new Scanner(System.in);

	public static void main(String[] args) {
		System.out.println("Please enter your choice");
		System.out.println("1 for save teacher");
		System.out.println("2 for get teacher by id");
		System.out.println("3 update teacher by id");
		System.out.println("4 delete teacher by id");
		System.out.println("5 delete all teachers");
		System.out.println("6 get all teacher");
		System.out.println("7 multiple");

		int i = scanner.nextInt();
		switch (i) {
		case 1: {

			System.out.println("enter the teacher id");
			int id = scanner.nextInt();
			scanner.nextLine();
			System.out.println("enter the teacher name");
			String name = scanner.nextLine();
			System.out.println("enter the subject");
			String subject = scanner.nextLine();
			System.out.println("enter the gender");
			String gender = scanner.next();

			com.proj.dto.Teacher teacher = new com.proj.dto.Teacher();
			teacher.setId(id);
			teacher.setName(name);
			teacher.setSub(subject);
			teacher.setGender(gender);

			TeacherDao dao = new TeacherDao();
			int j = dao.saveTeacher(teacher);
			if (j == 1) {
				System.out.println("teacher details saved successfully....TQ");
			} else {
				System.out.println("BSDK wrong hai.....");
			}

		}
			//System.out.println("i am save teacher");
			break;
		case 2: {
			Scanner scanner = new Scanner(System.in);
			System.out.println("enter the teacher id to delete");
			int id = scanner.nextInt();
			TeacherDao dao = new TeacherDao();
			int j = dao.deleteTeacherById(id);
			if (j != 0) {
				System.out.println("teacher details deleted sucessfully");
			} else {
				System.out.println("invalid id");
			}

		}

			break;
		case 3: {
			Scanner scanner = new Scanner(System.in);
			System.out.println("enter the teacher id ");
			int id = scanner.nextInt();
			TeacherDao dao = new TeacherDao();
			String result = dao.getTeacherById(id);
			if ("Invalid ID".equalsIgnoreCase(result)) {
				System.out.println("teacher not found with given id to update");

			} else {
				System.out.println("1 for updating the name");
				System.out.println("2 for updating the subject");
				System.out.println("3 for updating the gender");
				System.out.println("enter the choice");
				int choice = scanner.nextInt();
				switch (choice) {
				case 1: {
					String column = "subject";
					scanner.nextLine();
					System.out.println("enter new subject");
					String value = scanner.nextLine();
					TeacherDao teacherdao = new TeacherDao();
					int res = teacherdao.updateTeacher(id, column, value) ;
					if (res == 1) {
						System.out.println("sucessfully hogeya bsdk...");
					} else {
						System.out.println("AA tu jaa re....");
					}

				}
					break;

				default:System.out.println("invalid input please try...");
					break;
				}

			}
		}

			// System.out.println("i am update teacher");
			break;
		case 4: {
			Scanner scanner = new Scanner(System.in);
			System.out.println("enter the teacher id");
			int id = scanner.nextInt();
			TeacherDao dao = new TeacherDao();
			String result = dao.getTeacherById(id);
			System.out.println(result);

		}
			// System.out.println("i am delete teacher by id");
			break;
		case 5:{
			TeacherDao dao=new TeacherDao();
			int k=dao.clearAllTeacherData();
			if(k==1){
			System.out.println("heyegala re...");
			}
			else {
				
			System.out.println("wrong hai re deba..sudharle...");
				
			}
		}
			//System.out.println("i am delete all teacher");
			break;
		case 6:{
			TeacherDao dao=new TeacherDao();
			dao.getAllTeachersData();
		}
			//System.out.println("i am get all teacher");
			break;
		case 7 :
		{
			ArrayList<Teacher> teacher =new ArrayList<Teacher>();
			boolean flag = true;
			while(flag)
			{
				
			
			System.out.println("enter 1 to add teacher details");
			System.out.println("enter any other number to stop adding");
			int input = scanner .nextInt();
			if(input==1)
			{
				System.out.println("enter the teacher id");
				int id = scanner.nextInt();
				scanner.nextLine();
				System.out.println("enter the teacher name");
				String name = scanner.nextLine();
				System.out.println("enter the subject");
				String subject = scanner.nextLine();
				System.out.println("enter the gender");
				String gender = scanner.next();

				Teacher teacher1 = new Teacher();
				teacher1.setId(id);
				teacher1.setName(name);
				teacher1.setSub(subject);
				teacher1.setGender(gender);
				
				teacher.add(teacher1);
			}else {
				flag=false;

				
			}
			
			}
			TeacherDao dao=new TeacherDao();
			int res = dao.saveAllTeacher(teacher);
			if(res==1)
			{
				System.out.println("heyegala re...");
				
			}else {
				System.out.println("wrong hai re deba..sudharle...");
			}
		}
		break ;
		default:
			//System.out.println("i am get all teacher");

		}
	}
}
