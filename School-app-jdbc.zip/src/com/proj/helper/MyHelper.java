package com.proj.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class MyHelper {
public static Connection getConnection() {
	String url ="jdbc:mysql://localhost:3306/school_app_jdbc";
	String user ="root";
	String password="Deepak@026286";
	Connection connection=null;
	try {
		Class.forName("com.mysql.cj.jdbc.Driver");
		connection =DriverManager.getConnection(url, user, password);
		return connection ;
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return connection ;
}
}
