package com.proj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import com.proj.dto.Teacher;
import com.proj.helper.MyHelper;

public class TeacherDao {
public int saveTeacher(Teacher teacher) {
	String sql="INSERT INTO teacher VALUES(?,?,?,?)";
	Connection connection=MyHelper.getConnection();
	try {
		PreparedStatement ps =connection.prepareStatement(sql);
		ps.setInt(1,teacher.getId());
		ps.setString(2,teacher.getName());
		ps.setString(3,teacher.getSub());
		ps.setString(4,teacher.getGender());
		
		
		int i =ps.executeUpdate();
		connection.close();
		return i;
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return 0;
}


public String getTeacherById(int id)
{
String sql="SELECT * FROM teacher WHERE id="+id;
Connection connection =MyHelper .getConnection();
try {
	Statement statement=connection.createStatement();
	ResultSet resultset=statement.executeQuery(sql);
	while(resultset.next())
	{
		return "id : "+resultset.getInt(1)+" name : "+resultset.getString(2)+" sub : "+resultset.getString(3)+" gender : "+resultset.getString(4);
	}
} catch (Exception e) {
	// TODO: handle exception
	e.printStackTrace();
}
finally {
	try {
		connection.close();
	} catch (Exception e) {
		// TODO: handle exception
	}
}
return "invalid ID";
}


public int deleteTeacherById(int id)
{
	String sql="DELETE FROM teacher WHERE id="+id;
	Connection connection =MyHelper .getConnection();
	try {
		Statement statement=connection.createStatement();
		return statement.executeUpdate(sql) ;
	} catch (Exception e) {
		// TODO: handle exception
	}
	finally {
		try {
			connection.close();
		} catch (Exception e2) {
			// TODO: handle exception
		}
	}
	return 0;
}



public int updateTeacher(int id , String column , String value) {

String sql="UPDATE teacher SET "+column+" = '"+value+"' WHERE id="+id ;
Connection connection =MyHelper.getConnection();
try {
	Statement statement=connection.createStatement();
	return statement .executeUpdate(sql);

}
	
 catch (Exception e) {
	// TODO: handle exception
	 e.printStackTrace();
}
finally {
	try {
		connection.close();
	} catch (Exception e2) {
		// TODO: handle exception
	}
}

return 0;

}


public int clearAllTeacherData()
{
String sql="TRUNCATE TABLE teacher" ;
Connection connection =MyHelper .getConnection();
try {
	Statement statement =connection.createStatement();
	statement.execute(sql);
	connection.close();
	return 1;
	
} catch (Exception e) {
	// TODO: handle exception
}

	return 0;
}


public void getAllTeachersData()
{
	String sql="SELECT * FROM teacher" ;
	Connection connection=MyHelper.getConnection();
	try {
		Statement statement=connection.createStatement();
		ResultSet resultset=statement.executeQuery(sql);
		while(resultset.next()) {
			System.out.println("Id  : "+resultset.getInt(1));
			System.out.println("name  : "+resultset.getString(2));
			System.out.println("sub  : "+resultset.getString(3));
			System.out.println("gender  : "+resultset.getString(4));
			System.out.println("..........................................................");
		}
		
	} catch (Exception e) {
		// TODO: handle exception
	}
}

public int saveAllTeacher(ArrayList<Teacher> teachers) {
	String sql="INSERT INTO teacher VALUES(?,?,?,?)";
	Connection connection=MyHelper.getConnection();
	try {
		PreparedStatement ps =connection.prepareStatement(sql);
		for(Teacher teacher : teachers)
		{
		ps.setInt(1,teacher.getId());
		ps.setString(2,teacher.getName());
		ps.setString(3,teacher.getSub());
		ps.setString(4,teacher.getGender());
		
		ps.addBatch();
		}
		
	ps.executeBatch();
		connection.close();
		return 1;
	} catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	}
	return 0;
}

}












