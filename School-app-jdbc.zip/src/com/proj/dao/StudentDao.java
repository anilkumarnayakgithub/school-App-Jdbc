package com.proj.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.ArrayList;

import com.proj.dto.Student;
import com.proj.helper.MyHelper;

public class StudentDao {
	public String saveStudent(Student student) {
		String sql="INSERT INTO student values(?,?,?,?,?)";
		Connection connection=MyHelper.getConnection();
		try{
		PreparedStatement preparedstatement= connection.prepareStatement(sql);
		preparedstatement.setInt(1,student.getId());
		preparedstatement.setString(2,student.getName());
		preparedstatement.setInt(3,student.getAge());
		preparedstatement.setString(4,student.getGender());
		preparedstatement.setString(5,student.getEmail());


		preparedstatement.execute();
		connection.close();

		
		//String sql="INSERT INTO student VALUES("+student.getId()+",'"+student.getName()+"',"+student.getAge()+",'"+student.getgender()+"','"+student.getEmail()+"')";
		//Connection Connection =MyHelper.getConnection() ;
		//try {
	
		//Statement statement =Connection.createStatement();
		//statement.execute(sql);
		//Connection.close();
		return "data added sucessfully";
	}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return "data adding failed";
}


public void deletestudentById(int id) {
	String sql="DELETE FROM student WHERE id=?";
	Connection connection=MyHelper.getConnection() ;
	try {
		PreparedStatement preparedstatement= connection.prepareStatement(sql);
		preparedstatement.setInt(1, id);
		//int i=preparedstatement.executeUpdate();
		//System.out.println(i);
		
		//preparedstatement.execute();
connection.close();		

		}
	catch (Exception e) {
		// TODO: handle exception
		e.printStackTrace();
	
}
	
}

 public int saveAllStudent(ArrayList<Student> students)
 {
	 String sql="INSERT INTO student values(?,?,?,?,?)";
		Connection connection=MyHelper.getConnection();
		try {
			PreparedStatement preparedStatement=connection .prepareStatement(sql);
			for(Student student : students)
			{
				preparedStatement.setInt(1,student.getId());
				preparedStatement.setString(2,student.getName());
				preparedStatement.setInt(3,student.getAge());
				preparedStatement.setString(4,student.getGender());
				preparedStatement.setString(5,student.getEmail());
				preparedStatement.addBatch();

                 
				preparedStatement.executeBatch();
			}
			connection.close();
			return 1 ;
		} catch (Exception e) {
			// TODO: handle exception
		e.printStackTrace();
		}
 return 0 ;
 }
 
}


















